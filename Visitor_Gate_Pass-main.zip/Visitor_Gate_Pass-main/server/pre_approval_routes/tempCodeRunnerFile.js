localhost:3000/api/send-invitation 
//app password for smtp  server : rcgk ekwy tufw opdb