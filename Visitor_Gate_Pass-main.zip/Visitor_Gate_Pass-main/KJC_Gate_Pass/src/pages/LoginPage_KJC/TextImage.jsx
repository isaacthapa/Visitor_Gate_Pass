

function TextImage(){
    return(
    <div className="textImage">
        <div className="textOnly">
            <p id="text1">Security Management</p>
            <p id="text2">Rendering our service for the others</p>
        </div>
        {/* <img src="./src/assets/Image_LoginPage.svg" alt="LogoPIC.png" /> */}
    </div>
);
}

export default TextImage;