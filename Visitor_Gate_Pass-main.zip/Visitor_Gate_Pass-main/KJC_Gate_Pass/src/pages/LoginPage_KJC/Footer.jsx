

function Footer(){
    return(
        <div className="footer">
            <div className="CPtexts">
                <p>Copyright © 2024 Kristu Jayanti College</p>
                <p>All rights reserved</p>
            </div>
        </div>
    );
}

export default Footer;