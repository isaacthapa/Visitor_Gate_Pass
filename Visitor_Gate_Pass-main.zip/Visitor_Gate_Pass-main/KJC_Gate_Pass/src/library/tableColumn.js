export const totalVisitorCOLUMNS = [
  {
    Headers: "id",
    accessor: "_id",
  },
  {
    Headers: "Name",
    accessor: "name",
  },
  {
    Headers: "Phone",
    accessor: "_id",
  },
  {
    Headers: "id",
    accessor: "_id",
  },
  {
    Headers: "id",
    accessor: "_id",
  },
  {
    Headers: "id",
    accessor: "_id",
  },
];
